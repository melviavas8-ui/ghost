package newcode.module.impl.combat.rotation;

import net.minecraft.util.math.MathHelper;
import newcode.manager.IMinecraft;
import newcode.manager.Manager;
import newcode.utils.player.GCDUtil;
import org.joml.Vector2f;

public final class RotationController implements IMinecraft {
    private static final RotationController I = new RotationController();
    private final Vector2f rotate = new Vector2f(0.0F, 0.0F);
    private long resetStartTime = -1L;
    private long resetDuration = 0L;
    private float startYaw;
    private float startPitch;
    private float targetYaw;
    private float targetPitch;
    private boolean resetting = false;
    private boolean controlling = false;
    private boolean holdPacket = false;
    private static final float MAX_RETURN_YAW_STEP = 45.0F;
    private float lastSentYaw = 0.0F;
    private float lastSentPitch = 0.0F;
    private float prevSentYaw = 0.0F;
    private float prevSentPitch = 0.0F;
    private boolean hasSentYaw = false;
    private boolean pitchOverride = false;
    private float pitchOverrideValue = 0.0F;

    public static RotationController get() {
        return I;
    }

    private RotationController() {
    }

    public float getYaw() {
        return this.rotate.x;
    }

    public float getPitch() {
        return this.pitchOverride ? this.pitchOverrideValue : this.rotate.y;
    }

    public float toContinuous(float yaw) {
        return toContinuousYaw(this.rotate.x, yaw);
    }

    public void setPitchOverride(float pitch) {
        this.pitchOverride = true;
        this.pitchOverrideValue = MathHelper.clamp(pitch, -90.0F, 90.0F);
    }

    public void clearPitchOverride() {
        this.pitchOverride = false;
    }

    public boolean hasPitchOverride() {
        return this.pitchOverride;
    }

    public void set(float yaw, float pitch) {
        this.rotate.x = this.rotate.x + MathHelper.wrapDegrees(yaw - this.rotate.x);
        this.rotate.y = MathHelper.clamp(pitch, -90.0F, 90.0F);
        this.controlling = true;
        this.resetting = false;
        this.holdPacket = false;
        this.resetStartTime = -1L;
    }

    public void followCamera() {
        if (mc.player != null) {
            this.rotate.x = toContinuousYaw(this.rotate.x, mc.player.getYaw());
            this.rotate.y = mc.player.getPitch();
            this.controlling = false;
            this.resetting = false;
            this.holdPacket = false;
            this.resetStartTime = -1L;
        }
    }

    public void setContinuous(float yaw, float pitch) {
        this.rotate.x = this.rotate.x + MathHelper.wrapDegrees(yaw - this.rotate.x);
        this.rotate.y = MathHelper.clamp(pitch, -90.0F, 90.0F);
        this.controlling = true;
        this.resetting = false;
        this.holdPacket = false;
        this.resetStartTime = -1L;
    }

    public void setSmooth(float targetYaw, float targetPitch, float smooth, float maxYawStep, float maxPitchStep, boolean applyGcd) {
        float dYaw = MathHelper.wrapDegrees(targetYaw - this.rotate.x);
        float dPitch = targetPitch - this.rotate.y;
        float stepYaw = Math.min(Math.max(Math.abs(dYaw), 1.0F), maxYawStep);
        float stepPitch = Math.min(Math.max(Math.abs(dPitch), 1.0F), maxPitchStep);
        float appliedYaw = MathHelper.clamp((dYaw > 0.0F ? stepYaw : -stepYaw) * smooth, -180.0F, 180.0F);
        float ny = this.rotate.x + appliedYaw;
        float np = MathHelper.clamp(this.rotate.y + (dPitch > 0.0F ? stepPitch : -stepPitch) * smooth, -89.9F, 89.9F);
        if (applyGcd) {
            float gcd = GCDUtil.getGCDValue();
            ny -= (ny - this.rotate.x) % gcd;
            np -= (np - this.rotate.y) % gcd;
        }

        this.rotate.x = ny;
        this.rotate.y = np;
        this.controlling = true;
        this.resetting = false;
        this.holdPacket = false;
        this.resetStartTime = -1L;
    }

    public void smoothReturn(long durationMs) {
        if (mc.player != null) {
            float camYaw = mc.player.getYaw();
            float camPitch = mc.player.getPitch();
            float continuousCamYaw = toContinuousYaw(this.rotate.x, camYaw);
            float yawGap = Math.abs(continuousCamYaw - this.rotate.x);
            float pitchGap = Math.abs(camPitch - this.rotate.y);
            float wrappedGap = Math.abs(MathHelper.wrapDegrees(camYaw - this.rotate.x));
            if (!(wrappedGap < 1.0F) || !(yawGap < 0.5F) && !(Math.abs(this.rotate.x - camYaw) > 180.0F)) {
                if (durationMs > 0L && (!(yawGap < 0.5F) || !(pitchGap < 0.5F))) {
                    this.startYaw = this.rotate.x;
                    this.startPitch = this.rotate.y;
                    this.targetYaw = continuousCamYaw;
                    this.targetPitch = camPitch;
                    this.resetStartTime = System.currentTimeMillis();
                    this.resetDuration = Math.max(1L, durationMs);
                    this.resetting = true;
                } else {
                    this.finishReturn(continuousCamYaw, camPitch);
                }
            } else {
                this.finishReturn(continuousCamYaw, camPitch);
            }
        }
    }

    public void onUpdate() {
        this.controlling = false;
        this.tickReset();
    }

    public void prepareMotionPacket() {
        this.controlling = false;
    }

    public float peekCommitPacketYaw(float desiredYaw) {
        return !this.hasSentYaw ? desiredYaw : this.lastSentYaw + MathHelper.wrapDegrees(desiredYaw - this.lastSentYaw);
    }

    public float getMovementYaw() {
        return this.peekCommitPacketYaw(this.rotate.x);
    }

    private void tickReset() {
        if (this.resetting) {
            if (mc.player == null) {
                this.resetting = false;
                this.resetStartTime = -1L;
            } else {
                long elapsed = System.currentTimeMillis() - this.resetStartTime;
                if (this.resetDuration <= 0L) {
                    this.finishReturn(this.targetYaw, this.targetPitch);
                } else if (elapsed <= 0L) {
                    this.rotate.x = this.startYaw;
                    this.rotate.y = this.startPitch;
                } else {
                    float progress = (float)elapsed / (float)this.resetDuration;
                    if (progress >= 1.0F) {
                        this.finishReturn(this.targetYaw, MathHelper.clamp(this.targetPitch, -89.0F, 89.0F));
                    } else {
                        float eased = (float)(1.0 - Math.pow(1.0 - progress, 3.0));
                        float nextYaw = this.startYaw + (this.targetYaw - this.startYaw) * eased;
                        float yawStep = MathHelper.clamp(nextYaw - this.rotate.x, -45.0F, 45.0F);
                        this.rotate.x += yawStep;
                        this.rotate.y = MathHelper.clamp(this.startPitch + (this.targetPitch - this.startPitch) * eased, -89.0F, 89.0F);
                    }
                }
            }
        }
    }

    public boolean isControlling() {
        return this.pitchOverride || this.resetting || this.controlling || this.holdPacket;
    }

    public boolean isResetting() {
        return this.resetting;
    }

    public boolean isReturning() {
        return this.resetting || this.holdPacket;
    }

    public void updateIfFree(float yaw, float pitch) {
        if (!this.resetting && !this.holdPacket) {
            this.rotate.x = toContinuousYaw(this.rotate.x, yaw);
            if (!this.pitchOverride) {
                this.rotate.y = pitch;
            }
        }
    }

    public void prepareInteractRotation() {
        if (mc.player != null) {
            if (!viaOlderThan121()) {
                this.commitPacketYaw(mc.player.getYaw());
                this.commitPacketPitch(mc.player.getPitch());
            }
        }
    }

    public float getLastSentYaw() {
        if (!this.hasSentYaw) {
            return mc.player != null ? mc.player.getYaw() : 0.0F;
        } else {
            return this.lastSentYaw;
        }
    }

    public float getLastSentPitch() {
        if (!this.hasSentYaw) {
            return mc.player != null ? mc.player.getPitch() : 0.0F;
        } else {
            return this.lastSentPitch;
        }
    }

    public float getPrevSentYaw() {
        return !this.hasSentYaw ? this.getLastSentYaw() : this.prevSentYaw;
    }

    public float getPrevSentPitch() {
        return !this.hasSentYaw ? this.getLastSentPitch() : this.prevSentPitch;
    }

    private static boolean viaOlderThan121() {
        return Manager.VIA_MANAGER == null ? false : Manager.VIA_MANAGER.getActiveVersion().getProtocolId() < 767;
    }

    public float commitPacketYaw(float desiredYaw) {
        if (!this.hasSentYaw) {
            this.lastSentYaw = mc.player != null ? mc.player.getYaw() : desiredYaw;
            this.lastSentPitch = mc.player != null ? mc.player.getPitch() : 0.0F;
            this.prevSentYaw = this.lastSentYaw;
            this.prevSentPitch = this.lastSentPitch;
            this.hasSentYaw = true;
        } else {
            this.prevSentYaw = this.lastSentYaw;
        }

        float next = this.lastSentYaw + MathHelper.wrapDegrees(desiredYaw - this.lastSentYaw);
        this.lastSentYaw = next;
        this.rotate.x = next;
        return next;
    }

    public void commitPacketPitch(float desiredPitch) {
        if (this.hasSentYaw) {
            this.prevSentPitch = this.lastSentPitch;
        }

        this.lastSentPitch = MathHelper.clamp(desiredPitch, -90.0F, 90.0F);
    }

    public void afterMotionApplied() {
        this.holdPacket = false;
    }

    private void finishReturn(float yaw, float pitch) {
        this.rotate.x = toContinuousYaw(this.rotate.x, yaw);
        this.rotate.y = MathHelper.clamp(pitch, -90.0F, 90.0F);
        this.resetting = false;
        this.controlling = false;
        this.holdPacket = true;
        this.resetStartTime = -1L;
    }

    private static float toContinuousYaw(float fromYaw, float toYaw) {
        return fromYaw + MathHelper.wrapDegrees(toYaw - fromYaw);
    }
}
