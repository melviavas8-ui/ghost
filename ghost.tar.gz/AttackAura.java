package newcode.module.impl.combat;

import com.google.gson.JsonObject;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.Blocks;
import net.minecraft.block.SnowBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import newcode.events.Event;
import newcode.events.impl.EventPacket;
import newcode.events.impl.EventUpdate;
import newcode.events.impl.input.EventKeyBoard;
import newcode.events.impl.move.EventMotion;
import newcode.events.impl.player.EventAttackWindow;
import newcode.events.impl.player.EventAutoSprint;
import newcode.events.impl.player.EventPostUpdate;
import newcode.manager.IMinecraft;
import newcode.manager.Manager;
import newcode.mixin.accessor.ClientPlayerEntityAccessor;
import newcode.mixin.accessor.GameRendererAccessor;
import newcode.mixin.accessor.MinecraftClientAccessor;
import newcode.module.TypeList;
import newcode.module.api.Annotation;
import newcode.module.api.Module;
import newcode.module.impl.movement.AirStuck;
import newcode.module.settings.BooleanSetting;
import newcode.module.settings.ModeSetting;
import newcode.module.settings.MultiSetting;
import newcode.module.settings.SliderSetting;
import newcode.ui.clickgui.ClickGuiScreen;
import newcode.utils.IEntity;
import newcode.utils.math.RayTraceUtil;
import newcode.utils.move.MoveUtil;
import newcode.utils.player.AuraUtil;
import newcode.utils.player.GCDUtil;
import newcode.utils.render.RenderUtil;
import newcode.utils.rotation.ElytraRotationUtil;
import newcode.utils.rotation.FunTimeRotation;
import newcode.utils.rotation.RotationMath;
import newcode.utils.rotation.SpookyRotation;
import newcode.utils.rotation.SpookyRotationUtil;
import newcode.utils.via.AttackOrder;
import org.joml.Matrix4f;
import org.joml.Vector2f;

@Annotation(name = "AttackAura", desc = "Сам бьёт игроков и мобов рядом с вами", type = TypeList.Combat)
public class AttackAura extends Module {
    private static final float FOV_DISPLAY_ANGLE = 25.0F;
    private static final float LEGIT_SNAP_MAX_ROTATION = 35.0F;
    private static final long TARGET_UPDATE_INTERVAL = 100L;
    public final ModeSetting sort = new ModeSetting("Сортировать по", "Дистанции", "Дистанции", "Броне", "Хп");
    public final ModeSetting mode = new ModeSetting("Режим ротаций", "Smooth", "Smooth", "Snap", "FunTime", "Sloth", "Spooky", "LegitSnap");
    public final MultiSetting targets = new MultiSetting(
        "Выбор целей",
        Arrays.asList("Игроки", "Голые", "Невидимки", "Голые невидимки"),
        new String[]{"Игроки", "Голые", "Мобы", "Друзья", "Невидимки", "Голые невидимки"}
    );
    public final ModeSetting correctionType = new ModeSetting("Режим коррекции", "Сфокусированная", "Свободная", "Преследование", "Сфокусированная");
    public final SliderSetting distance = new SliderSetting("Дистанция атаки", 3.0, 0.1F, 6.0, 0.1F);
    public final SliderSetting rotateDistance = new SliderSetting("Дополнительная дистанция", 0.0, 0.0, 30.0, 0.1F);
    public final ModeSetting sprintResetMode = new ModeSetting("Мод спринта", "Пакетный", "Пакетный", "Легитный");
    public final MultiSetting noAttack = new MultiSetting("Не бить если", Arrays.asList("Используешь еду"), new String[]{"Открыт контейнер", "Используешь еду"});
    public final BooleanSetting onlyCrits = new BooleanSetting("Только критами", true);
    public final BooleanSetting smartCrits = new BooleanSetting("Криты только с пробелам", true, () -> this.onlyCrits.get());
    public final BooleanSetting adaptiveAttackSpeed = new BooleanSetting("Адаптивная скорость атаки", true);
    public final BooleanSetting releaseShield = new BooleanSetting("Отжимать щит", true);
    public final BooleanSetting breakShield = new BooleanSetting("Ломать щит", true);
    public final BooleanSetting hitThroughWalls = new BooleanSetting("Бить через стены", true);
    public final BooleanSetting hitThroughWallsBypas = new BooleanSetting("Обход через стены RW", false);
    public final BooleanSetting maceDamage = new BooleanSetting("Свапать на булаву", true);
    public final BooleanSetting displayFov = new BooleanSetting("Отображать FOV", true, () -> this.mode.is("LegitSnap"));
    private final List<LivingEntity> validTargets = new ArrayList<>();
    private final FunTimeRotation funTimeRotation = new FunTimeRotation();
    private final SpookyRotation spookyRotation = new SpookyRotation();
    private long spookyAttackGateOpenAtMs = System.currentTimeMillis();
    public LivingEntity target = null;
    private long lastTargetUpdate = 0L;
    private LivingEntity previousTarget = null;
    private long lastAttackTime = 0L;
    private int cpsLimit = 0;
    private int cachedCurrentTick;
    private int ticksSinceAttack = 10;
    private int funTimeTicksSinceHit = 10;
    private int preSprintTicks = 0;
    private int snapTicks = 0;
    private float slothHitFocus = 0.0F;
    private boolean funTimeHasRotation = false;
    private Item lastMainHandItem = null;
    private int macePreviousSlot = -1;
    private int maceInvSlot = -1;
    private int maceTempHotbarSlot = -1;
    private boolean maceSwapped = false;
    private boolean maceFromInventory = false;
    private int maceHeldTicks = 0;
    private int maceRestoreTicks = -1;
    private int maceInventorySyncTicks = 0;
    private boolean earlyHitRequested = true;
    private boolean attackedThisTick;
    private boolean maceTickedThisTick;
    private boolean attackWindowFiredThisTick;
    private int legitSprintResetTicks;
    private int shieldReleasedAge = Integer.MIN_VALUE;
    private float legitSnapTicksUntilNextAttack = 0.0F;
    private boolean legitSnapSilentThisTick;

    public AttackAura() {
        this.addSettings(
            this.targets,
            this.sort,
            this.mode,
            this.correctionType,
            this.distance,
            this.rotateDistance,
            this.sprintResetMode,
            this.displayFov,
            this.noAttack,
            this.onlyCrits,
            this.smartCrits,
            this.adaptiveAttackSpeed,
            this.releaseShield,
            this.breakShield,
            this.hitThroughWalls,
            this.hitThroughWallsBypas,
            this.maceDamage
        );
    }

    public static LivingEntity getTarget() {
        AttackAura aura = Manager.FUNCTION_MANAGER != null ? Manager.FUNCTION_MANAGER.attackAura : null;
        return aura != null ? aura.target : null;
    }

    public static float getEffectiveDistance() {
        AttackAura aura = Manager.FUNCTION_MANAGER != null ? Manager.FUNCTION_MANAGER.attackAura : null;
        float configured = aura != null ? aura.distance.get().floatValue() : 3.0F;
        AirStuck airStuck = Manager.FUNCTION_MANAGER != null ? Manager.FUNCTION_MANAGER.airStuck : null;
        return airStuck != null && airStuck.useIncreasedAuraDistance() ? airStuck.getAuraDistance() : configured;
    }

    public static void renderFovOverlay(float partialTicks, DrawContext context) {
        if (Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.attackAura != null && context != null) {
            AttackAura aura = Manager.FUNCTION_MANAGER.attackAura;
            if (aura.displayFov.get() && aura.mode.is("LegitSnap") && mc.player != null) {
                if (mc.options.getPerspective() == Perspective.FIRST_PERSON) {
                    Window window = mc.getWindow();
                    float guiScale = (float)window.getScaleFactor();
                    if (!(guiScale <= 0.0F)) {
                        float centerX = window.getFramebufferWidth() / 2.0F;
                        float centerY = window.getFramebufferHeight() / 2.0F;
                        float gameFov = ((GameRendererAccessor)mc.gameRenderer).invokeGetFov(mc.gameRenderer.getCamera(), partialTicks, true);
                        float halfHeight = window.getFramebufferHeight() / 2.0F;
                        float coneAngleRad = (float)Math.toRadians(25.0);
                        float radius = halfHeight * (float)(Math.tan(coneAngleRad) / Math.tan(Math.toRadians(gameFov * 0.5)));
                        MatrixStack matrices = context.getMatrices();
                        matrices.push();
                        matrices.scale(1.0F / guiScale, 1.0F / guiScale, 1.0F);
                        drawFovCircle(matrices, centerX, centerY, radius, 1.15F, -1);
                        matrices.pop();
                    }
                }
            }
        }
    }

    private static void drawFovCircle(MatrixStack matrices, float x, float y, float radius, float width, int color) {
        if (!(radius <= 0.0F) && !(width <= 0.0F)) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            int a = color >> 24 & 0xFF;
            int r = color >> 16 & 0xFF;
            int g = color >> 8 & 0xFF;
            int b = color & 0xFF;
            if (a == 0) {
                a = 255;
            }

            Matrix4f matrix = matrices.peek().getPositionMatrix();
            float feather = 0.55F;
            float rOuterSoft = radius + feather;
            float rOuter = radius;
            float rInner = Math.max(0.5F, radius - width);
            float rInnerSoft = Math.max(0.25F, rInner - feather);
            int segments = 360;
            BufferBuilder buffer = IMinecraft.tessellator().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

            for (int i = 0; i <= 360; i++) {
                float rad = (float)((Math.PI * 2) * i / 360.0);
                float cos = MathHelper.cos(rad);
                float sin = MathHelper.sin(rad);
                buffer.vertex(matrix, x + cos * rOuterSoft, y + sin * rOuterSoft, 0.0F).color(r, g, b, 0);
                buffer.vertex(matrix, x + cos * rOuter, y + sin * rOuter, 0.0F).color(r, g, b, a);
            }

            RenderUtil.render3D.endBuilding(buffer);
            buffer = IMinecraft.tessellator().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

            for (int i = 0; i <= 360; i++) {
                float rad = (float)((Math.PI * 2) * i / 360.0);
                float cos = MathHelper.cos(rad);
                float sin = MathHelper.sin(rad);
                buffer.vertex(matrix, x + cos * rOuter, y + sin * rOuter, 0.0F).color(r, g, b, a);
                buffer.vertex(matrix, x + cos * rInner, y + sin * rInner, 0.0F).color(r, g, b, a);
            }

            RenderUtil.render3D.endBuilding(buffer);
            buffer = IMinecraft.tessellator().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

            for (int i = 0; i <= 360; i++) {
                float rad = (float)((Math.PI * 2) * i / 360.0);
                float cos = MathHelper.cos(rad);
                float sin = MathHelper.sin(rad);
                buffer.vertex(matrix, x + cos * rInner, y + sin * rInner, 0.0F).color(r, g, b, a);
                buffer.vertex(matrix, x + cos * rInnerSoft, y + sin * rInnerSoft, 0.0F).color(r, g, b, 0);
            }

            RenderUtil.render3D.endBuilding(buffer);
            RenderSystem.disableBlend();
        }
    }

    @Override
    public void onEvent(Event event) {
        ClientPlayerEntity player = mc.player;
        if (player != null && !player.isDead()) {
            if (event instanceof EventKeyBoard e
                && (this.state || Manager.ROTATION.isReturning() || this.isFunTimeHoldingRotation())
                && !Manager.FUNCTION_MANAGER.freeCamera.state
                && !this.shouldYieldToWebTrap()) {
                this.applyMovementCorrection(e, player);
            }

            if (event instanceof EventAutoSprint e && this.target != null && this.isLegitSprintResetActive()) {
                e.setSprint(false);
                if (this.legitSprintResetTicks > 0) {
                    this.legitSprintResetTicks--;
                }
            }

            if (event instanceof EventAttackWindow window) {
                this.onAttackWindow(window);
            }

            if (event instanceof EventPacket packetEvent
                && packetEvent.isReceivePacket()
                && packetEvent.getPacket() instanceof GameMessageS2CPacket gameMessage
                && this.isSpooky()) {
                String text = gameMessage.content().getString();
                if (text != null && text.contains("Статистика боя")) {
                    this.spookyRotation.onCombatStatsMessage();
                }
            }

            boolean isPostUpdate = this.isPacketCritsPostUpdate();
            if (event instanceof EventUpdate) {
                if (!isPostUpdate) {
                    this.runCombatUpdate(player);
                } else if (this.mode.is("LegitSnap")) {
                    this.prepareLegitSnapRotation(player);
                }
            } else if (isPostUpdate && event instanceof EventPostUpdate) {
                this.runCombatUpdate(player);
            }

            if (event instanceof EventMotion motion
                && (this.target != null || this.isFunTimeHoldingRotation())
                && !this.shouldYieldToWebTrap()
                && (!this.mode.is("LegitSnap") || this.legitSnapSilentThisTick)) {
                motion.setYaw(Manager.ROTATION.getYaw());
                motion.setPitch(Manager.ROTATION.getPitch());
            }
        } else {
            this.resetMaceSwap(true);
            this.target = null;
            this.previousTarget = null;
            this.preSprintTicks = 0;
            this.legitSprintResetTicks = 0;
            this.cpsLimit = 0;
            this.ticksSinceAttack = 10;
            this.funTimeTicksSinceHit = 10;
            this.lastAttackTime = 0L;
            this.lastMainHandItem = null;
            this.funTimeHasRotation = false;
            this.funTimeRotation.reset();
            this.shieldReleasedAge = Integer.MIN_VALUE;
        }
    }

    public boolean isLegitSprintResetActive() {
        if (this.target == null) {
            return false;
        }

        if (this.legitSprintResetTicks > 0) {
            return true;
        }

        if ((this.sprintResetMode.is("Легитный") || this.sprintResetMode.is("Legit")) && AuraUtil.isUnderCeiling()) {
            boolean jumping = mc.player != null && mc.player.input != null && mc.player.input.playerInput.jump();
            if (jumping || mc.player != null && !mc.player.isOnGround()) {
                return true;
            }
        }

        return false;
    }

    @Override
    public void load(JsonObject object) {
        super.load(object);
        if ("FT Snap".equals(this.mode.get())) {
            this.mode.set("FunTime");
        }

        this.migrateEarlyHitSetting(object);
        this.migrateSprintSetting(object);
    }

    private void migrateSprintSetting(JsonObject object) {
        if (object != null && object.has("Settings") && object.get("Settings").isJsonObject()) {
            JsonObject settings = object.getAsJsonObject("Settings");
            if (settings.has("Режим сброса спринта") && !settings.has("Мод спринта")) {
                try {
                    String oldVal = settings.get("Режим сброса спринта").getAsString();
                    if ("Rage".equalsIgnoreCase(oldVal)) {
                        this.sprintResetMode.set("Пакетный");
                    } else if ("Legit".equalsIgnoreCase(oldVal)) {
                        this.sprintResetMode.set("Легитный");
                    }
                } catch (RuntimeException var4) {
                }
            }
        }
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        if ("FT Snap".equals(this.mode.get())) {
            this.mode.set("FunTime");
        }

        this.funTimeRotation.reset();
        this.funTimeHasRotation = false;
        this.funTimeTicksSinceHit = 10;
        this.spookyRotation.reset();
        this.resetMaceSwap(false);
    }

    private void migrateEarlyHitSetting(JsonObject object) {
        if (object != null && object.has("Settings") && object.get("Settings").isJsonObject()) {
            JsonObject settings = object.getAsJsonObject("Settings");
            if (settings.has("Ранний удар") && !settings.has("Адаптивная скорость атаки")) {
                try {
                    this.adaptiveAttackSpeed.set(!"Отключен".equals(settings.get("Ранний удар").getAsString()));
                } catch (RuntimeException var4) {
                }
            }
        }
    }

    private boolean isPacketCritsPostUpdate() {
        Criticals criticals = Manager.FUNCTION_MANAGER.criticals;
        return criticals != null && criticals.state
            ? criticals.mode.is("ReallyWorld")
                && (mc.player.hasStatusEffect(StatusEffects.SLOW_FALLING) || mc.player.hasStatusEffect(StatusEffects.LEVITATION) || Criticals.isPlayerInWeb())
            : false;
    }

    private void runCombatUpdate(ClientPlayerEntity player) {
        try {
            this.cachedCurrentTick = player.age;
            this.legitSnapSilentThisTick = false;
            if (!this.attackedThisTick) {
                this.ticksSinceAttack++;
            }

            this.funTimeTicksSinceHit++;
            this.attackedThisTick = false;
            if (!this.mode.is("FunTime") && (this.funTimeHasRotation || this.funTimeRotation.isActive())) {
                this.funTimeHasRotation = false;
                this.funTimeRotation.reset();
            }

            Item currentMainHandItem = player.getMainHandStack().getItem();
            if (this.lastMainHandItem != null && this.lastMainHandItem != currentMainHandItem) {
                this.cpsLimit = 0;
            }

            this.lastMainHandItem = currentMainHandItem;
            LivingEntity previousTargetRef = this.target;
            if (this.target == null || !this.isValidTarget(this.target)) {
                this.target = this.findTarget();
            }

            if (this.target != previousTargetRef) {
                this.cpsLimit = 0;
                ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
                if (et != null) {
                    ElytraTarget.resetPredictState();
                    et.resetChase();
                }
            }

            if (!this.maceTickedThisTick) {
                this.tickMaceSwap();
            }

            this.maceTickedThisTick = false;
            if (this.target != null) {
                this.previousTarget = this.target;
                this.prepareLegitSprintBeforeCombat(player);
                this.checkCeilingSprintReset(player);
                this.handleAttackAndRotation(this.target);
                if (this.mode.is("LegitSnap") && !this.isPacketCritsPostUpdate()) {
                    this.prepareLegitSnapRotation(player);
                }

                return;
            }

            this.legitSprintResetTicks = 0;
            this.cpsLimit = this.cachedCurrentTick;
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            if (et != null) {
                ElytraTarget.resetPredictState();
                et.resetChase();
            }

            if (this.shouldBeginCombatRotationRelease(this.previousTarget)) {
                this.releaseCombatRotation(this.previousTarget);
            }

            if (this.mode.is("FunTime")) {
                this.funTimeRotation.tickReturn();
                this.funTimeHasRotation = this.funTimeRotation.isActive();
            } else if (this.previousTarget == null && !Manager.ROTATION.isResetting() && !Manager.ROTATION.isReturning()) {
                this.funTimeRotation.reset();
                this.spookyRotation.reset();
            }

            this.previousTarget = null;
            this.snapTicks = 0;
            this.slothHitFocus = 0.0F;
            this.legitSnapTicksUntilNextAttack = 0.0F;
        } finally {
            this.attackWindowFiredThisTick = false;
        }
    }

    private boolean isLegitSprintMode() {
        return this.sprintResetMode.is("Легитный") || this.sprintResetMode.is("Legit");
    }

    private void prepareLegitSprintBeforeCombat(ClientPlayerEntity player) {
        if (this.isLegitSprintMode() && this.target != null && AuraUtil.needsSprintResetBeforeAttack(player)) {
            if (this.shouldAttack(this.target)) {
                if (Manager.FUNCTION_MANAGER.autoPotion == null || !Manager.FUNCTION_MANAGER.autoPotion.isActivePotion) {
                    AuraUtil.prepareLegitSprintStopClient(player);
                    this.legitSprintResetTicks = Math.max(this.legitSprintResetTicks, 2);
                }
            }
        }
    }

    private void checkCeilingSprintReset(ClientPlayerEntity player) {
        if (player != null
            && this.target != null
            && (this.sprintResetMode.is("Легитный") || this.sprintResetMode.is("Legit"))
            && AuraUtil.isUnderCeiling()
            && this.getDistance(this.target) <= this.attackDistance()) {
            boolean jumping = player.input != null && player.input.playerInput.jump();
            if (jumping || !player.isOnGround()) {
                AuraUtil.prepareLegitSprintStopClient(player);
                this.legitSprintResetTicks = Math.max(this.legitSprintResetTicks, 2);
            }
        }
    }

    @Override
    protected void onDisable() {
        boolean hadTarget = this.target != null;
        boolean wasResetting = Manager.ROTATION.isResetting();
        boolean hadFunTimeHold = this.isFunTimeHoldingRotation();
        boolean funTimeReturn = this.mode.is("FunTime") && (hadTarget || hadFunTimeHold);
        if (hadTarget
            && this.isValidTarget(this.target)
            && (this.useElytraSmoothRotation() || this.mode.is("Smooth") || this.mode.is("Sloth") || this.mode.is("FunTime") || this.isSpooky())) {
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            if (et != null) {
                ElytraTarget.resetPredictState();
                et.resetChase();
            }
        }

        this.target = null;
        this.previousTarget = null;
        this.snapTicks = 0;
        this.slothHitFocus = 0.0F;
        this.cpsLimit = 0;
        this.legitSprintResetTicks = 0;
        this.legitSnapSilentThisTick = false;
        this.legitSnapTicksUntilNextAttack = 0.0F;
        this.lastMainHandItem = null;
        this.funTimeTicksSinceHit = 10;
        this.spookyRotation.reset();
        this.spookyAttackGateOpenAtMs = System.currentTimeMillis();
        this.resetMaceSwap(true);
        this.shieldReleasedAge = Integer.MIN_VALUE;
        if (funTimeReturn && mc.player != null) {
            this.funTimeRotation.beginReturn();
            this.funTimeHasRotation = this.funTimeRotation.isActive();
        } else {
            this.funTimeHasRotation = false;
            this.funTimeRotation.reset();
            if (mc.player != null && (hadTarget || wasResetting || hadFunTimeHold)) {
                this.releaseRotationToCamera();
            }
        }

        super.onDisable();
    }

    private boolean shouldBeginCombatRotationRelease(LivingEntity previousCombatTarget) {
        if (previousCombatTarget != null) {
            return true;
        } else {
            return this.mode.is("FunTime")
                ? this.isFunTimeHoldingRotation() && !this.funTimeRotation.isReturning()
                : (Manager.ROTATION.isResetting() || this.isFunTimeHoldingRotation()) && !Manager.ROTATION.isReturning();
        }
    }

    private void releaseCombatRotation(LivingEntity releaseTarget) {
        boolean hadTarget = releaseTarget != null;
        boolean wasResetting = Manager.ROTATION.isResetting();
        boolean hadFunTimeHold = this.isFunTimeHoldingRotation();
        boolean funTimeReturn = this.mode.is("FunTime") && (hadTarget || hadFunTimeHold);
        if (hadTarget
            && this.isValidTarget(releaseTarget)
            && (this.useElytraSmoothRotation() || this.mode.is("Smooth") || this.mode.is("Sloth") || this.mode.is("FunTime") || this.isSpooky())) {
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            if (et != null) {
                ElytraTarget.resetPredictState();
                et.resetChase();
            }
        }

        if (funTimeReturn && mc.player != null) {
            this.funTimeRotation.beginReturn();
            this.funTimeHasRotation = this.funTimeRotation.isActive();
        } else {
            this.funTimeHasRotation = false;
            this.funTimeRotation.reset();
            if (mc.player != null && (hadTarget || wasResetting || hadFunTimeHold)) {
                this.releaseRotationToCamera();
            }
        }
    }

    private long getReleaseDurationMs() {
        if (this.isSpooky()) {
            return ThreadLocalRandom.current().nextLong(280L, 451L);
        } else {
            return !this.useElytraSmoothRotation() && !this.mode.is("Smooth") && !this.mode.is("Sloth") ? 0L : 220L;
        }
    }

    private boolean isSpooky() {
        return this.mode.is("Spooky");
    }

    private void releaseRotationToCamera() {
        if (mc.player != null) {
            Manager.ROTATION.smoothReturn(this.getReleaseDurationMs());
        }
    }

    private boolean isValidTarget(LivingEntity entity) {
        if (entity == null || entity.isDead() || !entity.isAlive() || entity == mc.player) {
            return false;
        }

        if (!AuraUtil.isTargetTypeAllowed(entity, this.targets)) {
            return false;
        }

        if (Manager.FUNCTION_MANAGER.antiBot.checkBot(entity)) {
            return false;
        }

        boolean keepMaceTarget = this.isMaceDiveRotating(entity);
        if (!keepMaceTarget && !this.hitThroughWalls.get() && !this.canAttackThroughWalls(entity)) {
            return false;
        }

        float elytraRotateBonus = 0.0F;
        ElytraTarget elytraTarget = Manager.FUNCTION_MANAGER.elytraTarget;
        if (mc.player.isGliding() && elytraTarget != null && elytraTarget.state) {
            elytraRotateBonus = elytraTarget.getChaseDistance();
        }

        float extraRotate = this.rotateDistance.get().floatValue();
        double maxTargetDistance = this.attackDistance() + elytraRotateBonus;
        if (extraRotate > 0.0F) {
            maxTargetDistance += extraRotate;
        }

        double entityDistance = mc.player.isGliding() ? this.getElytraReachDistance(entity) : this.getDistance(entity);
        if (keepMaceTarget) {
            maxTargetDistance = Math.max(maxTargetDistance, 15.0);
        }

        return keepMaceTarget || !(entityDistance > maxTargetDistance);
    }

    private LivingEntity findTarget() {
        long now = System.currentTimeMillis();
        if (now - this.lastTargetUpdate > 100L || this.target == null || !this.isValidTarget(this.target)) {
            this.validTargets.clear();
            this.updateValidTargets();
            this.lastTargetUpdate = now;
        }

        if (this.validTargets.isEmpty()) {
            return null;
        }

        if (this.validTargets.size() > 1) {
            switch (this.sort.get()) {
                case "Хп":
                    this.validTargets.sort(Comparator.comparing(LivingEntity::getHealth));
                    break;
                case "Дистанции":
                    this.validTargets.sort(Comparator.comparingDouble(this::getDistance));
                    break;
                case "Броне":
                    this.validTargets.sort(Comparator.comparingDouble(AuraUtil::getArmor));
            }
        }

        return this.validTargets.get(0);
    }

    private void updateValidTargets() {
        if (mc.player != null && mc.world != null) {
            float elytraRotateBonus = 0.0F;
            ElytraTarget elytraTarget = Manager.FUNCTION_MANAGER.elytraTarget;
            if (mc.player.isGliding() && elytraTarget != null && elytraTarget.state) {
                elytraRotateBonus = elytraTarget.getChaseDistance();
            }

            double maxDist = getEffectiveDistance() + this.rotateDistance.get().floatValue() + elytraRotateBonus;
            if (this.isMaceSwapActive()
                && !mc.player.isOnGround()
                && !mc.player.isGliding()
                && !mc.player.getAbilities().flying
                && (AuraUtil.hasMaceDiveVictim(this.target) || AuraUtil.hasMaceDiveVictim(null))) {
                maxDist = Math.max(maxDist, 15.0);
            }

            Box searchBox = mc.player.getBoundingBox().expand(maxDist);

            for (Entity entity : mc.world.getEntitiesByClass(LivingEntity.class, searchBox, e -> true)) {
                if (entity instanceof LivingEntity living && this.isValidTarget(living)) {
                    this.validTargets.add(living);
                }
            }
        }
    }

    private boolean useElytraSmoothRotation() {
        if (mc.player != null && mc.player.isGliding()) {
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            return et != null && et.state;
        } else {
            return false;
        }
    }

    private boolean usesGrimFastRotation() {
        if (!this.state || this.target == null || mc.player == null) {
            return false;
        } else {
            return this.useElytraSmoothRotation() ? true : this.mode.is("Smooth");
        }
    }

    private void refreshGrimFastRotation() {
        if (mc.player != null && this.target != null) {
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            if (et != null && et.state && mc.player.isGliding()) {
                ElytraTarget.smartPredict(this.target);
                et.updateChase(this.target);
                ElytraRotationUtil.applyGrimFastRotation(et.getAimPoint(this.target));
            } else {
                ElytraRotationUtil.applyGrimFastRotation(this.getSmoothAimPoint(this.target));
            }
        }
    }

    private void applySlothRotationAndAttack(LivingEntity t, boolean canAttackNow, boolean noPotion) {
        this.sloth(t, canAttackNow, this.getSlothAimVector(t));
        if (this.shouldAttackInCombatUpdate()) {
            this.performAttackIfReady(canAttackNow, noPotion);
        }
    }

    private Vec3d getSlothAimVector(LivingEntity targetEntity) {
        return this.getSmoothAimPoint(targetEntity).subtract(mc.player.getEyePos());
    }

    private void sloth(LivingEntity targetEntity, boolean canAttackNow, Vec3d aimVector) {
        if (targetEntity != null && mc.player != null) {
            if (aimVector.lengthSquared() <= 1.0E-4) {
                aimVector = this.getSmoothAimPoint(targetEntity).subtract(mc.player.getEyePos());
            }

            float currentYaw = Manager.ROTATION.getYaw();
            float currentPitch = Manager.ROTATION.getPitch();
            float rawTargetYaw = (float)Math.toDegrees(Math.atan2(aimVector.z, aimVector.x)) - 90.0F;
            float targetYaw = RotationMath.adjustAngle(currentYaw, rawTargetYaw);
            float targetPitch = MathHelper.clamp((float)(-Math.toDegrees(Math.atan2(aimVector.y, Math.hypot(aimVector.x, aimVector.z)))), -90.0F, 90.0F);
            float diffYaw = RotationMath.getAngleDifference(currentYaw, targetYaw);
            float diffPitch = targetPitch - currentPitch;
            float baseYaw = currentYaw + diffYaw * 0.68F;
            float basePitch = currentPitch + diffPitch * 0.68F;
            float focusTarget = this.slothHitFocusTarget(canAttackNow);
            this.slothHitFocus = this.slothHitFocus + (focusTarget - this.slothHitFocus) * 0.24F;
            double now = System.currentTimeMillis() / 1000.0;
            float helixYaw = (float)(Math.sin(now * 18.0) * 14.0 + Math.cos(now * 9.0) * 6.0);
            float helixPitch = (float)(Math.cos(now * 18.0) * 10.0 + Math.sin(now * 9.0) * 5.0);
            float helixScale = 1.0F - this.slothHitFocus * 0.88F;
            helixYaw *= helixScale;
            helixPitch *= helixScale;
            Manager.ROTATION.setContinuous(baseYaw + helixYaw, MathHelper.clamp(basePitch + helixPitch, -89.9F, 89.9F));
        }
    }

    private float slothHitFocusTarget(boolean canAttackNow) {
        if (mc.player == null) {
            return 0.0F;
        }

        if (canAttackNow) {
            return 1.0F;
        }

        float cooldown = mc.player.getAttackCooldownProgress(0.0F);
        return cooldown < 0.58F ? 0.0F : MathHelper.clamp((cooldown - 0.58F) / 0.42F, 0.0F, 1.0F);
    }

    private void handleAttackAndRotation(LivingEntity t) {
        boolean canAttackNow = this.shouldAttack(t);
        boolean noPotion = !Manager.FUNCTION_MANAGER.autoPotion.isActivePotion;
        if (this.usesGrimFastRotation()) {
            this.refreshGrimFastRotation();
            if (this.shouldAttackInCombatUpdate()) {
                this.performAttackIfReady(canAttackNow, noPotion);
            }
        } else if (this.mode.is("Sloth")) {
            this.applySlothRotationAndAttack(t, canAttackNow, noPotion);
        } else if (this.isSpooky()) {
            this.applySpookyRotation(t, this.isSpookyRotationUrgent(t));
            boolean attackReady = this.shouldAttack(t);
            this.performAttackIfReady(attackReady, noPotion);
        } else if (!this.mode.is("FunTime")) {
            if (this.mode.is("Snap")) {
                if (this.shouldAttackInCombatUpdate()) {
                    this.performAttackIfReady(canAttackNow, noPotion);
                }

                if (this.snapTicks < 3) {
                    this.setRotation(t, true);
                    this.snapTicks++;
                } else {
                    Manager.ROTATION.set(mc.player.getYaw(), mc.player.getPitch());
                }
            } else {
                if (this.mode.is("LegitSnap")) {
                    this.applyLegitSnapRotationAndAttack(t, canAttackNow, noPotion);
                }
            }
        } else {
            boolean hitUrgency = canAttackNow && noPotion;
            this.applyFunTimeRotation(t, hitUrgency);
            this.performAttackIfReady(canAttackNow, noPotion);
        }
    }

    private void performAttackIfReady(boolean canAttackNow, boolean noPotion) {
        if (this.mode.is("FunTime")) {
            if (canAttackNow && noPotion && this.funTimeTicksSinceHit >= 4) {
                this.attackTarget(mc.player);
            }
        } else if (this.mode.is("Snap")) {
            if (canAttackNow && this.canAttack() && noPotion) {
                this.attackTarget(mc.player);
                this.snapTicks = 0;
            }
        } else {
            if (canAttackNow && noPotion) {
                this.attackTarget(mc.player);
            }
        }
    }

    private boolean shouldAttackInCombatUpdate() {
        return this.isSpooky() ? true : this.isPacketCritsPostUpdate() || !this.attackWindowFiredThisTick;
    }

    private boolean isSpookyRotationUrgent(LivingEntity entity) {
        if (entity != null && mc.player != null && this.isSpooky()) {
            if (System.currentTimeMillis() < this.spookyAttackGateOpenAtMs) {
                return false;
            }

            if (this.getDistance(entity) > this.attackDistance()) {
                return false;
            }

            float threshold = 0.94F;
            return mc.player.getAttackCooldownProgress(0.0F) >= threshold;
        } else {
            return false;
        }
    }

    private void onAttackWindow(EventAttackWindow event) {
        this.attackWindowFiredThisTick = true;
        if (event.isPre() && mc.player != null) {
            this.cachedCurrentTick = mc.player.age;
            this.tickMaceSwap();
            this.maceTickedThisTick = true;
            this.prepareLegitSprintBeforeCombat(mc.player);
            this.checkCeilingSprintReset(mc.player);
        }

        if (!this.isPacketCritsPostUpdate()) {
            if (!this.mode.is("FunTime") && !this.isSpooky()) {
                if (this.adaptiveAttackSpeed.get()) {
                    this.tryWindowAttack(!event.isPost());
                } else if (event.isPre()) {
                    this.tryWindowAttack(true);
                }
            }
        }
    }

    private void tryWindowAttack(boolean earlyRequested) {
        if (this.target != null) {
            this.earlyHitRequested = earlyRequested;

            try {
                boolean canAttackNow = this.shouldAttack(this.target);
                boolean noPotion = Manager.FUNCTION_MANAGER.autoPotion == null || !Manager.FUNCTION_MANAGER.autoPotion.isActivePotion;
                this.performAttackIfReady(canAttackNow, noPotion);
            } finally {
                this.earlyHitRequested = true;
            }
        }
    }

    private float getHitCooldownBaseTime() {
        if (this.earlyHitRequested) {
            return 0.5F;
        } else {
            return mc.getRenderTickCounter() == null ? 0.0F : mc.getRenderTickCounter().getLastFrameDuration();
        }
    }

    private boolean canUseVanillaHitWindow() {
        if (this.earlyHitRequested) {
            return true;
        } else {
            return mc.getRenderTickCounter() == null ? false : mc.getRenderTickCounter().getLastFrameDuration() > 0.3F;
        }
    }

    private void applyFunTimeRotation(LivingEntity targetEntity, boolean hitUrgency) {
        if (targetEntity != null && mc.player != null) {
            this.funTimeRotation.update(targetEntity, hitUrgency);
            this.funTimeHasRotation = true;
        }
    }

    public void tickFunTimeReturnIfDisabled() {
        if (!this.state && this.mode.is("FunTime") && mc.player != null) {
            this.funTimeRotation.tickReturn();
            this.funTimeHasRotation = this.funTimeRotation.isActive();
        }
    }

    public boolean isFunTimeHoldingRotation() {
        return this.mode.is("FunTime") && mc.player != null && (this.funTimeHasRotation || this.funTimeRotation.isActive());
    }

    private void applySpookyRotation(LivingEntity targetEntity, boolean canAttackNow) {
        if (targetEntity != null && mc.player != null) {
            Vector2f current = new Vector2f(Manager.ROTATION.getYaw(), Manager.ROTATION.getPitch());
            boolean elytraChase = Manager.FUNCTION_MANAGER.elytraTarget != null
                && Manager.FUNCTION_MANAGER.elytraTarget.state
                && Manager.FUNCTION_MANAGER.elytraTarget.hasChasePosition();
            Vector2f next = this.spookyRotation.update(targetEntity, current, getEffectiveDistance(), this.spookyAttackGateOpenAtMs, canAttackNow, elytraChase);
            Manager.ROTATION.setContinuous(next.x, next.y);
        }
    }

    private void scheduleSpookyAttackGate() {
        long delay = 500L;
        if (mc.player != null && mc.player.hasStatusEffect(StatusEffects.HASTE)) {
            int amp = mc.player.getStatusEffect(StatusEffects.HASTE).getAmplifier() + 1;
            if (amp >= 3) {
                float factor = 1.0F - (0.08F + ThreadLocalRandom.current().nextFloat() * 0.03F);
                delay = (long)((float)delay * factor);
            }
        }

        this.spookyAttackGateOpenAtMs = System.currentTimeMillis() + delay;
    }

    private boolean spookyAttackRayTrace(LivingEntity entity) {
        if (entity == null || mc.player == null) {
            return false;
        }

        if (!this.hitThroughWalls.get() && !this.canAttackThroughWalls(entity) && !this.isReallyWorldWallBypass(entity)) {
            return false;
        }

        double reach = this.spookyRotation.isCombatStatsMode() ? this.attackDistance() : Math.min(this.attackDistance(), 3.0);
        float yaw = Manager.ROTATION.getYaw();
        float pitch = Manager.ROTATION.getPitch();
        return SpookyRotationUtil.raycastTarget(entity, yaw, pitch, reach) != null;
    }

    private void applyMovementCorrection(EventKeyBoard e, ClientPlayerEntity player) {
        if (this.shouldCorrectMovement()) {
            if (Manager.ROTATION.isReturning()) {
                this.applyResetMovementCorrection(e);
            } else {
                float packetYaw = this.getMovementCorrectionYaw();
                float cameraYaw = player.getYaw();
                if (this.correctionType.is("Свободная")) {
                    if (this.mode.is("LegitSnap") && !this.legitSnapSilentThisTick) {
                        return;
                    }

                    MoveUtil.fixMovement(e, packetYaw, cameraYaw);
                } else if (this.correctionType.is("Преследование")) {
                    MoveUtil.fixMovementToTarget(e, packetYaw, this.target);
                } else if (this.correctionType.is("Сфокусированная")) {
                    if (this.mode.is("LegitSnap") && !this.legitSnapSilentThisTick) {
                        return;
                    }

                    MoveUtil.fixMovementToRotation(e, packetYaw);
                }
            }
        }
    }

    public void applyResetMovementCorrection(EventKeyBoard event) {
        if (mc.player != null) {
            float packetYaw = Manager.ROTATION.getMovementYaw();
            MoveUtil.fixMovement(event, packetYaw, mc.player.getYaw());
        }
    }

    private Vec3d getSmoothAimPoint(LivingEntity targetEntity) {
        if (mc.player != null && mc.player.isGliding()) {
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            if (et != null && et.state) {
                return et.getAimPoint(targetEntity);
            }
        }

        return ElytraTarget.getHitboxCenter(targetEntity);
    }

    private void setRotation(LivingEntity entity, boolean applyGcd) {
        Vec3d tp = this.pos(entity);
        double dx = tp.x - mc.player.getX();
        double dy = tp.y + entity.getEyeHeight(entity.getPose()) / 2.0 - (mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()));
        double dz = tp.z - mc.player.getZ();
        float rawYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float yaw = RotationMath.adjustAngle(Manager.ROTATION.getYaw(), rawYaw);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
        Manager.ROTATION.setSmooth(yaw, pitch, 1.2F, 180.0F, 15.0F, applyGcd);
    }

    private boolean shouldSkipAttack() {
        return mc.player != null && this.noAttack.get("Открыт контейнер") && this.isContainerOpen();
    }

    private boolean isContainerOpen() {
        return mc.currentScreen != null && !(mc.currentScreen instanceof ClickGuiScreen);
    }

    public void attackTarget(PlayerEntity player) {
        Item offhandItem = mc.player.getOffHandStack().getItem();
        if (!mc.player.isUsingItem()
            || mc.player.getActiveHand() != Hand.OFF_HAND
            || offhandItem != Items.GOLDEN_APPLE && offhandItem != Items.ENCHANTED_GOLDEN_APPLE) {
            boolean usingOffhandFood = false;
        } else {
            boolean usingOffhandFood = true;
        }

        if (!this.shouldSkipAttack()) {
            if (!this.mode.is("LegitSnap") || this.canLegitSnapAttack(this.target)) {
                boolean resumeOffhandEat = false;
                if (!this.releasedShieldThisTick()) {
                    if (!this.releaseShield.get() || !this.releaseShield()) {
                        if (!this.trySwapMaceForSmashAttack()) {
                            if (this.applyReallyWorldWallSpoof(this.target)) {
                                if (AuraUtil.needsSprintResetBeforeAttack(mc.player)) {
                                    switch (this.sprintResetMode.get()) {
                                        case "Пакетный":
                                        case "Rage":
                                            ((ClientPlayerEntityAccessor)mc.player).setLastSprinting(false);
                                            mc.player.setSprinting(false);
                                            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, Mode.STOP_SPRINTING));
                                            break;
                                        case "Легитный":
                                        case "Legit":
                                            AuraUtil.prepareLegitSprintStopClient(mc.player);
                                            this.legitSprintResetTicks = Math.max(this.legitSprintResetTicks, 2);
                                            if (!AuraUtil.isLegitSprintSyncedForAttack(mc.player)) {
                                                return;
                                            }
                                    }
                                }

                                if (this.breakShield.get() && !this.shouldUseMace()) {
                                    this.breakShield(this.target);
                                }

                                AttackOrder.sendFixedAttack(player, this.target, Hand.MAIN_HAND);
                                this.attackedThisTick = true;
                                this.ticksSinceAttack = 0;
                                this.funTimeTicksSinceHit = 0;
                                SyncTps syncTps = Manager.FUNCTION_MANAGER.syncTps;
                                if (this.shouldUseMace()) {
                                    this.cpsLimit = this.cachedCurrentTick;
                                } else {
                                    int cooldown = syncTps != null ? syncTps.scaleTicks(10) : 10;
                                    this.cpsLimit = this.cachedCurrentTick + cooldown;
                                }

                                this.lastAttackTime = System.currentTimeMillis();
                                this.funTimeRotation.onAttack();
                                if (this.isSpooky()) {
                                    this.scheduleSpookyAttackGate();
                                }

                                if (this.mode.is("LegitSnap")) {
                                    float viewYaw = mc.player.getYaw();
                                    float viewPitch = mc.player.getPitch();
                                    if (!this.isLegitSnapRayTrace(this.target, viewYaw, viewPitch)
                                        && this.isTargetCenterInCrosshairFov(this.target, 25.0F, viewYaw, viewPitch)) {
                                        this.legitSnapTicksUntilNextAttack = 2.0F;
                                    }
                                }

                                if (this.maceSwapped) {
                                    this.maceRestoreTicks = 4;
                                }

                                if (resumeOffhandEat) {
                                    mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
                                    mc.player.swingHand(Hand.OFF_HAND);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean shouldYieldToWebTrap() {
        WebTrap webTrap = Manager.FUNCTION_MANAGER != null ? Manager.FUNCTION_MANAGER.webTrap : null;
        return webTrap != null && webTrap.shouldHoldCombat();
    }

    private boolean shouldAttack(LivingEntity targetEntity) {
        if (this.shouldYieldToWebTrap()) {
            return false;
        } else if (targetEntity == null) {
            return false;
        } else {
            return this.cpsLimit > this.cachedCurrentTick && !this.shouldUseMace() ? false : this.canAttack();
        }
    }

    public boolean canAttack() {
        if (mc.player == null || this.target == null) {
            return false;
        }

        if (this.noAttack.get("Используешь еду")
            && mc.player.isUsingItem()
            && !mc.player.isBlocking()
            && mc.player.getItemUseTimeLeft() > 0
            && this.ticksSinceAttack >= 8) {
            this.ticksSinceAttack = 8;
            return false;
        }

        if (this.noAttack.get("Открыт контейнер") && this.isContainerOpen()) {
            return false;
        }

        SyncTps syncTps = Manager.FUNCTION_MANAGER.syncTps;
        boolean maceSmash = this.shouldUseMace();
        if (mc.player.isGliding()) {
            if (!maceSmash && this.getElytraReachDistance(this.target) > this.attackDistance()) {
                return false;
            }
        } else if (maceSmash) {
            if (!AuraUtil.willMaceSmashThisEntity(this.target)) {
                return false;
            }
        } else if (!this.isMaceDiveRotating(this.target)) {
            if (this.getDistance(this.target) > this.attackDistance()) {
                return false;
            }
        } else if (this.getDistance(this.target) > 15.0) {
            return false;
        }

        if (!this.isMaceSwapActive() || this.target == null || mc.player.isOnGround() || maceSmash || !this.maceSwapped && !this.isWaitingForMaceSmash()) {
            if (syncTps != null && !syncTps.isChargeReady(this.ticksSinceAttack) && !maceSmash) {
                return false;
            }

            if (this.isMaceSwapActive() && this.maceRestoreTicks > 0 && !maceSmash) {
                return false;
            }

            if (!maceSmash && !this.canUseVanillaHitWindow()) {
                return false;
            }

            boolean itemCooling = mc.player.getItemCooldownManager().isCoolingDown(mc.player.getMainHandStack());
            boolean holdingMace = mc.player.getMainHandStack().isOf(Items.MACE);
            float cooldownProgress = mc.player.getAttackCooldownProgress(this.getHitCooldownBaseTime());
            if (maceSmash) {
                if (itemCooling || AuraUtil.isMaceOnItemCooldown()) {
                    return false;
                }

                if (!holdingMace && this.findMaceSlot() == -1) {
                    return false;
                }

                if (mc.player.fallDistance <= 2.5F) {
                    return false;
                }

                if (this.maceInventorySyncTicks > 0) {
                    return false;
                }
            } else {
                if (holdingMace && this.isMaceSwapActive() && !mc.player.isOnGround() && AuraUtil.isMaceDiveCommitted(this.target) && !maceSmash) {
                    return false;
                }

                if (holdingMace) {
                    if (itemCooling || cooldownProgress < 0.92F) {
                        return false;
                    }
                } else if (this.isSpooky()) {
                    float threshold = ThreadLocalRandom.current().nextFloat() * 0.035000026F + 0.96F;
                    if (mc.player.getAttackCooldownProgress(0.0F) < threshold) {
                        return false;
                    }

                    if (System.currentTimeMillis() < this.spookyAttackGateOpenAtMs) {
                        return false;
                    }

                    if (!this.spookyAttackRayTrace(this.target)) {
                        return false;
                    }
                } else if (cooldownProgress < 0.9F) {
                    return false;
                }
            }

            if (maceSmash) {
                return true;
            }

            if (!this.onlyCrits.get()) {
                return true;
            }

            if (Criticals.isGrimPacketCrits()) {
                return !mc.player.isOnGround();
            }

            if (Criticals.isWebAscending()) {
                return true;
            }

            if (this.shouldSkipCritCheck()) {
                return true;
            }

            boolean jumping = mc.player.input != null && mc.player.input.playerInput.jump();
            boolean fallingCrit = this.isSpooky()
                ? AuraUtil.hasCritFallDistance(ThreadLocalRandom.current().nextFloat() * 0.018F + 0.002F)
                    && AuraUtil.canCritEnvironment()
                    && !mc.player.isOnGround()
                : AuraUtil.isCrit();
            return fallingCrit || this.smartCrits.get() && mc.player.isOnGround() && !jumping || !AuraUtil.canCritEnvironment();
        } else {
            return false;
        }
    }

    public boolean shouldSkipCritCheck() {
        StatusEffectInstance slowness = mc.player.getStatusEffect(StatusEffects.SLOWNESS);
        if (slowness != null) {
            int slownessLevel = slowness.getAmplifier() + 1;
            if (slownessLevel >= 5 && slownessLevel <= 10) {
                return true;
            }
        }

        return this.shouldSkipOnlyCritsCheck();
    }

    private boolean shouldSkipOnlyCritsCheck() {
        if (mc.player != null && mc.world != null) {
            BlockPos feetPos = BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ());
            boolean inSnow = false;
            if (mc.world.getBlockState(feetPos).isOf(Blocks.SNOW)) {
                inSnow = mc.world.getBlockState(feetPos).get(SnowBlock.LAYERS) == 2;
            }

            boolean inBerryBush = mc.world.getBlockState(feetPos).getBlock() instanceof SweetBerryBushBlock;
            boolean waterOnlyCritsBypass = mc.player.isTouchingWater() && mc.player.isSubmergedIn(FluidTags.WATER);
            boolean lavaOnlyCritsBypass = mc.player.isInLava() && mc.player.isSubmergedIn(FluidTags.LAVA);
            boolean airStuckBypass = Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.airStuck != null && Manager.FUNCTION_MANAGER.airStuck.state;
            boolean inWeb = ((IEntity)mc.player).newcodeFabric1_21_4$isInWeb() && !Criticals.usesSmoothWebCrits();
            return inWeb
                || mc.player.isGliding()
                || mc.player.getAbilities().flying
                || mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
                || mc.player.isClimbing()
                || mc.player.hasVehicle()
                || mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                || waterOnlyCritsBypass
                || lavaOnlyCritsBypass
                || inSnow
                || inBerryBush
                || airStuckBypass;
        } else {
            return false;
        }
    }

    private int toContainerSlot(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }

    private boolean isMaceSwapActive() {
        return this.maceDamage.get() && this.hasMace();
    }

    private boolean hasMace() {
        return mc.player == null ? false : mc.player.getMainHandStack().isOf(Items.MACE) || this.findMaceSlot() != -1;
    }

    private boolean isWaitingForMaceSmash() {
        if (!this.isMaceSwapActive() || AuraUtil.isMaceOnItemCooldown() || this.target == null || !this.isValidTarget(this.target)) {
            return false;
        } else if (mc.player == null || mc.player.isOnGround() || mc.player.isGliding() || mc.player.getAbilities().flying || AuraUtil.isMaceFallCancelled()) {
            return false;
        } else if (mc.player.fallDistance < 2.5F) {
            return false;
        } else {
            return AuraUtil.canMaceSmashAttackNow(this.target)
                ? false
                : this.maceSwapped || this.canMaceSmashThisFall() || this.shouldPreSwapMace() || this.canPrepareEarlyMaceSwap();
        }
    }

    private boolean canMaceSmashThisFall() {
        if (!this.isMaceSwapActive() || mc.player == null || mc.world == null) {
            return false;
        } else if (AuraUtil.isMaceOnItemCooldown()) {
            return false;
        } else if (this.target != null && !this.isValidTarget(this.target)) {
            return false;
        } else if (mc.player.isOnGround() || mc.player.isGliding() || mc.player.getAbilities().flying) {
            return false;
        } else if (AuraUtil.isMaceFallCancelled()) {
            return false;
        } else if (mc.player.fallDistance < 2.5F) {
            return false;
        } else {
            return !AuraUtil.canCritEnvironment() ? false : AuraUtil.hasMaceDiveVictim(this.target);
        }
    }

    private boolean isMaceSmashWindow() {
        return AuraUtil.isInMaceSmashAttackWindow(this.target);
    }

    private boolean shouldUseMace() {
        if (!this.isMaceSwapActive() || mc.player == null || this.target == null || !this.isValidTarget(this.target)) {
            return false;
        } else {
            return AuraUtil.isMaceOnItemCooldown() ? false : AuraUtil.canMaceSmashAttackNow(this.target);
        }
    }

    private boolean isMaceDiveRotating(LivingEntity entity) {
        if (!this.isMaceSwapActive() || entity == null || mc.player == null) {
            return false;
        } else if (mc.player.isOnGround() || mc.player.isGliding() || mc.player.getAbilities().flying) {
            return false;
        } else if (AuraUtil.isMaceFallCancelled()) {
            return false;
        } else {
            return this.getDistance(entity) > 15.0 ? false : AuraUtil.hasMaceDiveVictim(entity) || AuraUtil.willMaceSmashThisEntity(entity);
        }
    }

    private int findMaceSlot() {
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.MACE) {
                return i;
            }
        }

        return -1;
    }

    private void tickMaceSwap() {
        if (!this.maceDamage.get() || mc.player == null || !this.maceSwapped && !this.hasMace()) {
            if (this.maceSwapped) {
                this.restoreMaceSlot();
            }
        } else {
            if (this.maceInventorySyncTicks > 0) {
                this.maceInventorySyncTicks--;
            }

            if (this.maceRestoreTicks > 0) {
                this.maceRestoreTicks--;
                if (this.maceRestoreTicks == 0) {
                    this.restoreMaceSlot();
                }
            } else {
                if (this.maceSwapped) {
                    this.maceHeldTicks++;
                    if (this.shouldRestoreMace()) {
                        this.restoreMaceSlot();
                    }
                }

                if (this.shouldPreSwapMace()) {
                    this.swapToMaceForAttack();
                    this.maceHeldTicks = 0;
                }
            }
        }
    }

    private boolean shouldRestoreMace() {
        if (mc.player.isOnGround() || mc.player.getAbilities().flying || AuraUtil.isMaceFallCancelled()) {
            return true;
        } else if (this.target != null && !this.isValidTarget(this.target)) {
            return true;
        } else {
            return !this.isMaceSmashWindow() && !AuraUtil.shouldKeepMaceForDive(this.target) ? mc.player.isGliding() || mc.player.fallDistance < 2.5F : false;
        }
    }

    private boolean canPrepareEarlyMaceSwap() {
        if (!this.isMaceSwapActive() || mc.player == null) {
            return false;
        } else if (this.target == null || !this.isValidTarget(this.target)) {
            return false;
        } else if (mc.player.isOnGround() || mc.player.isGliding() || mc.player.getAbilities().flying) {
            return false;
        } else if (AuraUtil.isMaceFallCancelled() || AuraUtil.isMaceOnItemCooldown()) {
            return false;
        } else if (mc.player.fallDistance < 2.5F) {
            return false;
        } else {
            int maceSlot = this.findMaceSlot();
            if (maceSlot == -1 && !mc.player.getMainHandStack().isOf(Items.MACE)) {
                return false;
            } else {
                return !AuraUtil.canCritEnvironment() ? false : AuraUtil.hasMaceDiveVictim(this.target);
            }
        }
    }

    private boolean shouldPreSwapMace() {
        if (!this.isMaceSwapActive() || mc.player == null) {
            return false;
        }

        if (this.target == null || !this.isValidTarget(this.target)) {
            return false;
        }

        if (!this.maceSwapped && this.maceRestoreTicks < 0) {
            if (mc.player.getMainHandStack().getItem() == Items.MACE) {
                return false;
            }

            if (!mc.player.isOnGround() && !mc.player.getAbilities().flying && !AuraUtil.isMaceFallCancelled()) {
                int maceSlot = this.findMaceSlot();
                if (maceSlot == -1) {
                    return false;
                } else if (AuraUtil.isMaceOnItemCooldown()) {
                    return false;
                } else if (mc.player.fallDistance < 2.5F) {
                    return false;
                } else {
                    return this.canPrepareEarlyMaceSwap()
                        ? true
                        : this.canMaceSmashThisFall() && (this.isMaceSmashWindow() || AuraUtil.willBeMaceSmashReadyWithin(14, 2.5F));
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean trySwapMaceForSmashAttack() {
        if (this.shouldUseMace() && mc.player != null) {
            this.swapToMaceForAttack();
            return this.maceFromInventory && this.maceInventorySyncTicks > 0;
        } else {
            return false;
        }
    }

    private void resetMaceSwap(boolean restoreSlot) {
        if (restoreSlot) {
            this.restoreMaceSlot();
        }

        this.maceHeldTicks = 0;
        this.maceRestoreTicks = -1;
        this.maceInventorySyncTicks = 0;
    }

    private boolean swapToMaceForAttack() {
        if (mc.player.getMainHandStack().getItem() == Items.MACE) {
            return true;
        }

        if (this.maceSwapped) {
            return true;
        }

        int maceSlot = this.findMaceSlot();
        if (maceSlot == -1) {
            return mc.player.getMainHandStack().getItem() == Items.MACE;
        }

        int currentSlot = mc.player.getInventory().selectedSlot;
        if (maceSlot < 9) {
            if (maceSlot == currentSlot) {
                return true;
            }

            this.macePreviousSlot = currentSlot;
            mc.player.getInventory().selectedSlot = maceSlot;
            mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(maceSlot));
            this.maceSwapped = true;
            return true;
        } else {
            this.macePreviousSlot = currentSlot;
            this.maceInvSlot = maceSlot;
            this.maceTempHotbarSlot = (currentSlot + 1) % 9;
            this.maceFromInventory = true;
            mc.interactionManager
                .clickSlot(mc.player.currentScreenHandler.syncId, this.toContainerSlot(maceSlot), this.maceTempHotbarSlot, SlotActionType.SWAP, mc.player);
            mc.player.getInventory().selectedSlot = this.maceTempHotbarSlot;
            mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(this.maceTempHotbarSlot));
            this.maceInventorySyncTicks = 1;
            this.maceSwapped = true;
            return true;
        }
    }

    private void restoreMaceSlot() {
        this.maceHeldTicks = 0;
        this.maceRestoreTicks = -1;
        this.maceInventorySyncTicks = 0;
        if (this.maceSwapped) {
            if (this.maceFromInventory) {
                mc.player.getInventory().selectedSlot = this.macePreviousSlot;
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(this.macePreviousSlot));
                mc.interactionManager
                    .clickSlot(
                        mc.player.currentScreenHandler.syncId, this.toContainerSlot(this.maceInvSlot), this.maceTempHotbarSlot, SlotActionType.SWAP, mc.player
                    );
            } else if (this.macePreviousSlot != -1) {
                mc.player.getInventory().selectedSlot = this.macePreviousSlot;
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(this.macePreviousSlot));
            }

            this.macePreviousSlot = -1;
            this.maceInvSlot = -1;
            this.maceTempHotbarSlot = -1;
            this.maceFromInventory = false;
            this.maceSwapped = false;
        }
    }

    public boolean shouldSuppressVanillaUse() {
        return this.state && this.releaseShield.get() && this.releasedShieldThisTick();
    }

    private boolean releasedShieldThisTick() {
        return mc.player != null && this.shieldReleasedAge == mc.player.age;
    }

    private boolean releaseShield() {
        if (mc.player != null && mc.interactionManager != null && mc.player.isBlocking()) {
            mc.interactionManager.stopUsingItem(mc.player);
            this.shieldReleasedAge = mc.player.age;
            MinecraftClientAccessor accessor = (MinecraftClientAccessor)mc;
            if (accessor.getUseCooldown() < 2) {
                accessor.setUseCooldown(2);
            }

            return true;
        } else {
            return false;
        }
    }

    private void breakShield(LivingEntity shieldTarget) {
        if (shieldTarget != null && mc.player != null) {
            if (shieldTarget instanceof PlayerEntity entity && entity.isBlocking() && !entity.isSpectator() && !entity.isCreative()) {
                int axeSlot = -1;

                for (int i = 0; i < 36; i++) {
                    ItemStack stack = mc.player.getInventory().getStack(i);
                    if (!stack.isEmpty() && stack.getItem() instanceof AxeItem) {
                        axeSlot = i;
                        break;
                    }
                }

                if (axeSlot != -1) {
                    int currentHotbarSlot = mc.player.getInventory().selectedSlot;
                    boolean axeInHotbar = axeSlot < 9;
                    if (axeInHotbar) {
                        if (axeSlot != currentHotbarSlot) {
                            mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(axeSlot));
                        }

                        AttackOrder.sendFixedAttack(mc.player, entity, Hand.MAIN_HAND);
                        if (axeSlot != currentHotbarSlot) {
                            mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(currentHotbarSlot));
                        }
                    } else {
                        int tempHotbarSlot = (currentHotbarSlot + 1) % 9;
                        mc.interactionManager
                            .clickSlot(mc.player.currentScreenHandler.syncId, this.toContainerSlot(axeSlot), tempHotbarSlot, SlotActionType.SWAP, mc.player);
                        mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(tempHotbarSlot));
                        AttackOrder.sendFixedAttack(mc.player, entity, Hand.MAIN_HAND);
                        mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(currentHotbarSlot));
                        mc.interactionManager
                            .clickSlot(mc.player.currentScreenHandler.syncId, this.toContainerSlot(axeSlot), tempHotbarSlot, SlotActionType.SWAP, mc.player);
                    }

                    if (Manager.NOTIFICATION_MANAGER != null) {
                        String protectedName = Manager.FUNCTION_MANAGER.nameProtect.getProtectedName(entity.getName().getString());
                        Manager.NOTIFICATION_MANAGER.addShieldBreak(Text.literal(protectedName));
                    }
                }
            }
        }
    }

    private Vec3d pos(LivingEntity e) {
        return e.getPos();
    }

    public double attackDistance() {
        return getEffectiveDistance();
    }

    private double getDistance(LivingEntity entity) {
        if (entity != null && mc.player != null) {
            Box box = AuraUtil.getReachTargetBox(entity);
            return box == null ? Double.MAX_VALUE : AuraUtil.getMinReachToBox(mc.player.getEyePos(), box);
        } else {
            return Double.MAX_VALUE;
        }
    }

    private double getElytraReachDistance(LivingEntity entity) {
        if (entity != null && mc.player != null) {
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            if (et != null && et.state) {
                double combatDist = et.getCombatDistance(entity);
                return et.hasChasePosition() ? Math.min(combatDist, et.getPredictedDistance()) : combatDist;
            } else {
                Box box = AuraUtil.getReachTargetBox(entity);
                return box == null ? Double.MAX_VALUE : AuraUtil.getMinReachToBox(mc.player.getEyePos(), box);
            }
        } else {
            return Double.MAX_VALUE;
        }
    }

    public float getExtraRotationDistance() {
        return this.rotateDistance.get().floatValue();
    }

    public double getRotationTraceDistance() {
        double dist = getEffectiveDistance() + this.rotateDistance.get().floatValue();
        if (this.target != null && this.isMaceDiveRotating(this.target)) {
            dist = Math.max(dist, 15.0);
        }

        return dist;
    }

    private boolean isLookingAtPredict() {
        if (this.target != null && mc.player != null && mc.player.isGliding()) {
            ElytraTarget et = Manager.FUNCTION_MANAGER.elytraTarget;
            if (et != null && et.state) {
                Box predictBox = et.getPredictBox(this.target);
                if (predictBox == null) {
                    return false;
                }

                Box hitBox = predictBox.expand(0.2);
                if (RayTraceUtil.rayTraceBox(Manager.ROTATION.getYaw(), Manager.ROTATION.getPitch(), hitBox)) {
                    return true;
                }

                if (RayTraceUtil.rayTraceBox(mc.player.getYaw(), mc.player.getPitch(), hitBox)) {
                    return true;
                }

                if (this.mode.is("FunTime")) {
                    float sentYaw = MathHelper.wrapDegrees(Manager.ROTATION.getLastSentYaw());
                    float sentPitch = Manager.ROTATION.getLastSentPitch();
                    if (RayTraceUtil.rayTraceBox(sentYaw, sentPitch, hitBox)) {
                        return true;
                    }
                }

                return false;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean rayTraceForAttack() {
        if (this.shouldUseMace()) {
            return this.rayTraceMaceSmash();
        } else {
            return this.isSpooky() && this.target != null ? this.spookyAttackRayTrace(this.target) : this.rayTrace();
        }
    }

    private boolean rayTraceMaceSmash() {
        if (this.target == null) {
            return false;
        } else if (!this.isReallyWorldWallBypass(this.target) && !AuraUtil.willMaceSmashThisEntity(this.target) && !this.isLookingAtPredict()) {
            double reach = 3.4;
            return RayTraceUtil.rayTraceEntity(Manager.ROTATION.getYaw(), Manager.ROTATION.getPitch(), reach, this.target);
        } else {
            return true;
        }
    }

    public boolean shouldCorrectMovement() {
        if (mc.player == null || Manager.FUNCTION_MANAGER.freeCamera.state) {
            return false;
        } else {
            return Manager.ROTATION.isReturning() ? true : this.state && this.target != null || this.isFunTimeHoldingRotation();
        }
    }

    public boolean isLegitSnapSilent() {
        return this.mode.is("LegitSnap") && this.legitSnapSilentThisTick;
    }

    public float getMovementCorrectionYaw() {
        if (mc.player == null) {
            return 0.0F;
        } else if (Manager.ROTATION.isReturning()) {
            return Manager.ROTATION.getMovementYaw();
        } else if (this.mode.is("LegitSnap") && !this.legitSnapSilentThisTick) {
            return mc.player.getYaw();
        } else {
            return (!this.state || this.target == null) && !this.isFunTimeHoldingRotation() ? mc.player.getYaw() : Manager.ROTATION.getMovementYaw();
        }
    }

    public float getMovementCorrectionPitch() {
        if (mc.player == null) {
            return 0.0F;
        } else if (Manager.ROTATION.isReturning()) {
            return Manager.ROTATION.getPitch();
        } else if (this.mode.is("LegitSnap") && !this.legitSnapSilentThisTick) {
            return mc.player.getPitch();
        } else {
            return (!this.state || this.target == null) && !this.isFunTimeHoldingRotation() ? mc.player.getPitch() : Manager.ROTATION.getPitch();
        }
    }

    public boolean isControllingRotation() {
        if (mc.player == null) {
            return false;
        } else {
            return this.mode.is("LegitSnap")
                ? this.legitSnapSilentThisTick || this.isFunTimeHoldingRotation()
                : this.state && this.target != null || this.isFunTimeHoldingRotation();
        }
    }

    private boolean isReallyWorldWallBypass(LivingEntity entity) {
        return this.hitThroughWallsBypas.get() && entity != null && !this.canAttackThroughWalls(entity);
    }

    private boolean applyReallyWorldWallSpoof(LivingEntity targetEntity) {
        if (!this.isReallyWorldWallBypass(targetEntity)) {
            return true;
        }

        float tickDelta = mc.getRenderTickCounter().getTickDelta(true);
        Vec3d startVec = mc.player.getCameraPosVec(tickDelta);
        Vec3d targetPos = targetEntity.getCameraPosVec(tickDelta);
        Vec3d direction = targetPos.subtract(startVec);
        double distance = direction.length();
        if (distance < 0.001) {
            return false;
        }

        Vec3d normalizedDir = direction.normalize();

        for (double i = 0.0; i < distance; i += 0.5) {
            Vec3d point = startVec.add(normalizedDir.multiply(i));
            BlockPos pos = BlockPos.ofFloored(point);
            if (!mc.world.isAir(pos)) {
                mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.START_DESTROY_BLOCK, pos, Direction.UP));
                mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.STOP_DESTROY_BLOCK, pos, Direction.UP));
            }
        }

        return true;
    }

    private boolean canAttackThroughWalls(LivingEntity targetEntity) {
        if (targetEntity != null && mc.player != null && mc.world != null) {
            Vec3d targetVec = targetEntity.getPos().add(0.0, targetEntity.getEyeHeight(targetEntity.getPose()), 0.0);
            Vec3d playerVec = mc.player.getPos().add(0.0, mc.player.getEyeHeight(mc.player.getPose()), 0.0);
            return mc.world.raycast(new RaycastContext(playerVec, targetVec, ShapeType.COLLIDER, FluidHandling.NONE, mc.player)).getType() == Type.MISS;
        } else {
            return false;
        }
    }

    public boolean rayTrace() {
        return this.target == null ? false : this.getDistance(this.target) <= this.attackDistance();
    }

    public boolean rayTraceAim() {
        return this.rayTrace();
    }

    private void prepareLegitSnapRotation(ClientPlayerEntity player) {
        this.legitSnapSilentThisTick = false;
        if (this.mode.is("LegitSnap") && player != null && this.target != null && !this.shouldYieldToWebTrap() && !Manager.ROTATION.isReturning()) {
            float viewYaw = player.getYaw();
            float viewPitch = player.getPitch();
            boolean aimed = this.isLegitSnapRayTrace(this.target, viewYaw, viewPitch);
            boolean inFov = this.isTargetCenterInCrosshairFov(this.target, 25.0F, viewYaw, viewPitch);
            if (!aimed && inFov && this.legitSnapTicksUntilNextAttack > 0.0F) {
                this.setLegitSnapRotation(this.target, viewYaw, viewPitch);
                this.legitSnapSilentThisTick = true;
                this.legitSnapTicksUntilNextAttack--;
            } else {
                if (aimed || !inFov) {
                    this.legitSnapTicksUntilNextAttack = 0.0F;
                }

                Manager.ROTATION.followCamera();
            }
        }
    }

    private void applyLegitSnapRotationAndAttack(LivingEntity t, boolean canAttackNow, boolean noPotion) {
        float viewYaw = mc.player.getYaw();
        float viewPitch = mc.player.getPitch();
        boolean aimed = this.isLegitSnapRayTrace(t, viewYaw, viewPitch);
        boolean inFov = this.isTargetCenterInCrosshairFov(t, 25.0F, viewYaw, viewPitch);
        boolean canAttackLegitSnap = aimed || inFov;
        if (this.shouldAttackInCombatUpdate() && canAttackLegitSnap && canAttackNow && noPotion) {
            this.attackTarget(mc.player);
        }
    }

    private void setLegitSnapRotation(LivingEntity base, float viewYaw, float viewPitch) {
        if (this.target != null && mc.player != null) {
            Vec3d eyePos = mc.player.getEyePos();
            Box bb = this.target.getBoundingBox();
            if (bb != null) {
                bb = bb.expand(-0.1);
                double closestX = MathHelper.clamp(eyePos.x, bb.minX, bb.maxX);
                double closestZ = MathHelper.clamp(eyePos.z, bb.minZ, bb.maxZ);
                double diffX = closestX - eyePos.x;
                double diffZ = closestZ - eyePos.z;
                double distXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
                double pitchRad = Math.toRadians(viewPitch);
                double lookingY = eyePos.y - distXZ * Math.tan(pitchRad);
                double closestY = MathHelper.clamp(lookingY, bb.minY, bb.maxY);
                Vec3d targetVec = new Vec3d(closestX, closestY, closestZ);
                Vec3d diff = targetVec.subtract(eyePos);
                float neededYaw = (float)Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0F;
                float neededPitch = MathHelper.clamp((float)(-Math.toDegrees(Math.atan2(diff.y, Math.hypot(diff.x, diff.z)))), -90.0F, 90.0F);
                float gcd = GCDUtil.getGCDValue();
                neededYaw -= (neededYaw - viewYaw) % gcd;
                neededPitch -= (neededPitch - viewPitch) % gcd;
                Manager.ROTATION.set(neededYaw, neededPitch);
            }
        }
    }

    private boolean canLegitSnapAttack(LivingEntity entity) {
        if (entity != null && mc.player != null) {
            float viewYaw = mc.player.getYaw();
            float viewPitch = mc.player.getPitch();
            return this.isLegitSnapRayTrace(entity, viewYaw, viewPitch) || this.isTargetCenterInCrosshairFov(entity, 25.0F, viewYaw, viewPitch);
        } else {
            return false;
        }
    }

    private boolean isLegitSnapRayTrace(LivingEntity entity, float viewYaw, float viewPitch) {
        return entity != null && mc.player != null ? RayTraceUtil.getMouseOver(entity, viewYaw, viewPitch, this.attackDistance()) == entity : false;
    }

    private boolean isLegitSnapEngaged(LivingEntity entity, float viewYaw, float viewPitch) {
        if (!this.isTargetCenterInCrosshairFov(entity, 25.0F, viewYaw, viewPitch)) {
            return false;
        }

        float[] centerRotation = this.getRotationToPoint(entity.getBoundingBox().getCenter());
        if (!this.isRotationDeltaWithin(viewYaw, viewPitch, centerRotation, 35.0F)) {
            return false;
        }

        float[] aimRotation = this.getNeededAimRotation(entity, viewPitch);
        return this.isRotationDeltaWithin(viewYaw, viewPitch, aimRotation, 35.0F);
    }

    private boolean isTargetCenterInCrosshairFov(LivingEntity entity, float maxAngleDegrees, float viewYaw, float viewPitch) {
        if (entity != null && mc.player != null) {
            Box bb = entity.getBoundingBox();
            if (bb == null) {
                return false;
            } else {
                Vec3d eyePos = mc.player.getEyePos();
                Vec3d lookVec = RayTraceUtil.getVectorForRotation(viewPitch, viewYaw);
                Vec3d toTarget = bb.getCenter().subtract(eyePos);
                double lookLen = lookVec.length();
                double targetLen = toTarget.length();
                if (!(lookLen < 1.0E-6) && !(targetLen < 1.0E-6)) {
                    double dot = lookVec.dotProduct(toTarget) / (lookLen * targetLen);
                    dot = MathHelper.clamp(dot, -1.0, 1.0);
                    return Math.toDegrees(Math.acos(dot)) <= maxAngleDegrees;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }
    }

    private boolean isRotationDeltaWithin(float yaw, float pitch, float[] needed, float maxDegrees) {
        float yawDelta = Math.abs(MathHelper.wrapDegrees(needed[0] - yaw));
        float pitchDelta = Math.abs(needed[1] - pitch);
        return yawDelta <= maxDegrees && pitchDelta <= maxDegrees;
    }

    private float[] getRotationToPoint(Vec3d point) {
        Vec3d eyePos = mc.player.getEyePos();
        Vec3d diff = point.subtract(eyePos);
        double diffXZ = Math.hypot(diff.x, diff.z);
        if (diffXZ < 1.0E-6) {
            return new float[]{mc.player.getYaw(), mc.player.getPitch()};
        }

        float neededYaw = (float)Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0F;
        float neededPitch = MathHelper.clamp((float)(-Math.toDegrees(Math.atan2(diff.y, diffXZ))), -90.0F, 90.0F);
        return new float[]{neededYaw, neededPitch};
    }

    private float[] getNeededAimRotation(LivingEntity entity, float currentPitch) {
        return this.getRotationToPoint(this.getAimPointForRotation(entity, currentPitch));
    }

    private Vec3d getAimPointForRotation(LivingEntity base, float currentPitch) {
        Vec3d eyePos = mc.player.getEyePos();
        Box bb = base.getBoundingBox();
        if (bb == null) {
            return base.getPos().add(0.0, base.getHeight() / 2.0, 0.0);
        }

        bb = bb.expand(-0.1);
        double closestX = MathHelper.clamp(eyePos.x, bb.minX, bb.maxX);
        double closestZ = MathHelper.clamp(eyePos.z, bb.minZ, bb.maxZ);
        double diffX = closestX - eyePos.x;
        double diffZ = closestZ - eyePos.z;
        double distXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        double pitchRad = Math.toRadians(currentPitch);
        double lookingY = eyePos.y - distXZ * Math.tan(pitchRad);
        double closestY = MathHelper.clamp(lookingY, bb.minY, bb.maxY);
        return new Vec3d(closestX, closestY, closestZ);
    }
}
